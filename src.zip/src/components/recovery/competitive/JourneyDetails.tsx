'use client';

import { useMemo, useState } from 'react';
import dayjs from 'dayjs';
import Leaderboard from './Leaderboard';
import FailureFeed from './FailureFeed';
import type { JourneyDetailsResponse } from './types';

interface JourneyDetailsProps {
  details: JourneyDetailsResponse | null;
  isLoading: boolean;
  onJoin: () => Promise<void>;
  onLeave: () => Promise<void>;
  onFail: () => Promise<void>;
  onCheckIn: (note?: string) => Promise<void>;
  onInvite: (input: { username?: string; email?: string }) => Promise<void>;
  onAddConsequence: (input: {
    failureThreshold: number;
    description: string;
    consequenceType?: 'text' | 'symbolic' | 'warning' | 'penalty';
    symbol?: string;
  }) => Promise<void>;
  onEncourage: (input: { toUserId?: string; emoji?: string; message?: string }) => Promise<void>;
}

export default function JourneyDetails({
  details,
  isLoading,
  onJoin,
  onLeave,
  onFail,
  onCheckIn,
  onInvite,
  onAddConsequence,
  onEncourage,
}: JourneyDetailsProps) {
  const [inviteUsername, setInviteUsername] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const [newThreshold, setNewThreshold] = useState('');
  const [newConsequenceDescription, setNewConsequenceDescription] = useState('');
  const [newConsequenceType, setNewConsequenceType] = useState<'text' | 'symbolic' | 'warning' | 'penalty'>('text');
  const [newConsequenceSymbol, setNewConsequenceSymbol] = useState('');

  const [encourageTarget, setEncourageTarget] = useState('');
  const [encourageEmoji, setEncourageEmoji] = useState('👏');
  const [encourageMessage, setEncourageMessage] = useState('Stay locked in.');

  const activeParticipants = useMemo(
    () => details?.participants.filter((participant) => participant.status !== 'left') || [],
    [details]
  );

  if (isLoading && !details) {
    return (
      <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-5">
        <div className="font-mono text-xs text-on-surface-variant">
          <span className="animate-blink text-primary">▊</span> Loading competitive journey...
        </div>
      </div>
    );
  }

  if (!details) {
    return (
      <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-5">
        <div className="font-mono text-xs text-on-surface-variant">
          Select a journey to view leaderboard, failures, rules, and consequences.
        </div>
      </div>
    );
  }

  const isOwner = details.myMembership?.role === 'owner';
  const canFail = details.myMembership?.status === 'active';

  const handleInvite = async () => {
    await onInvite({
      username: inviteUsername.trim() || undefined,
      email: inviteEmail.trim() || undefined,
    });
    setInviteUsername('');
    setInviteEmail('');
  };

  const handleConsequence = async () => {
    const threshold = Number(newThreshold);
    if (!Number.isInteger(threshold) || threshold <= 0) return;
    if (!newConsequenceDescription.trim()) return;

    await onAddConsequence({
      failureThreshold: threshold,
      description: newConsequenceDescription.trim(),
      consequenceType: newConsequenceType,
      symbol: newConsequenceSymbol.trim() || undefined,
    });

    setNewThreshold('');
    setNewConsequenceDescription('');
    setNewConsequenceType('text');
    setNewConsequenceSymbol('');
  };

  const handleEncourage = async () => {
    await onEncourage({
      toUserId: encourageTarget || undefined,
      emoji: encourageEmoji || '👏',
      message: encourageMessage.trim() || undefined,
    });
    setEncourageMessage('Stay locked in.');
  };

  const fallbackCopyText = (text: string) => {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', 'true');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, textarea.value.length);
    const copied = document.execCommand('copy');
    document.body.removeChild(textarea);
    return copied;
  };

  const copyInviteLink = async (path: string) => {
    const url = `${window.location.origin}${path}`;
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
      } else {
        const copied = fallbackCopyText(url);
        if (!copied) throw new Error('Fallback copy failed');
      }
      setCopyFeedback('Invite link copied.');
    } catch {
      setCopyFeedback('Could not copy automatically. Manually copy the invite link shown below.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-headline text-xl font-bold text-on-surface">{details.journey.name}</h3>
              <span
                className={`px-2 py-0.5 rounded-sm font-mono text-[10px] ${
                  details.journey.visibility === 'public'
                    ? 'bg-secondary/20 text-secondary'
                    : 'bg-tertiary/20 text-tertiary'
                }`}
              >
                {details.journey.visibility.toUpperCase()}
              </span>
            </div>
            {details.journey.description && (
              <p className="font-body text-sm text-on-surface-variant mt-1">{details.journey.description}</p>
            )}
            <div className="font-mono text-[10px] text-outline mt-1">
              started {dayjs(details.journey.startDate).format('MMM D, YYYY HH:mm')}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {details.canJoin && (
              <button
                onClick={onJoin}
                className="px-3 py-2 rounded-sm bg-secondary/20 text-secondary font-label text-[10px] uppercase tracking-wider font-bold"
              >
                Join Journey
              </button>
            )}
            {details.myMembership && details.myMembership.role !== 'owner' && (
              <button
                onClick={onLeave}
                className="px-3 py-2 rounded-sm bg-surface-container-high text-on-surface-variant font-label text-[10px] uppercase tracking-wider"
              >
                Leave
              </button>
            )}
            {canFail && (
              <button
                onClick={onFail}
                className="px-3 py-2 rounded-sm bg-error-container text-on-error-container font-label text-[10px] uppercase tracking-wider font-bold"
              >
                I Failed
              </button>
            )}
            {canFail && details.ruleSummary.structured.mandatoryDailyCheckIn && (
              <button
                onClick={() => onCheckIn('daily check-in')}
                className="px-3 py-2 rounded-sm bg-primary/20 text-primary font-label text-[10px] uppercase tracking-wider font-bold"
              >
                Daily Check-in
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-surface-container-lowest border border-outline-variant/15 rounded-sm p-3">
            <div className="font-mono text-[10px] text-on-surface-variant uppercase">Participants</div>
            <div className="font-headline text-xl font-bold text-primary">{activeParticipants.length}</div>
          </div>
          <div className="bg-surface-container-lowest border border-outline-variant/15 rounded-sm p-3">
            <div className="font-mono text-[10px] text-on-surface-variant uppercase">Total Failures</div>
            <div className="font-headline text-xl font-bold text-error">{details.recentFailures.length}</div>
          </div>
          <div className="bg-surface-container-lowest border border-outline-variant/15 rounded-sm p-3">
            <div className="font-mono text-[10px] text-on-surface-variant uppercase">Consequence Rules</div>
            <div className="font-headline text-xl font-bold text-tertiary">{details.consequences.length}</div>
          </div>
          <div className="bg-surface-container-lowest border border-outline-variant/15 rounded-sm p-3">
            <div className="font-mono text-[10px] text-on-surface-variant uppercase">Max Failures</div>
            <div className="font-headline text-xl font-bold text-secondary">
              {details.ruleSummary.maxFailures ?? '∞'}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-surface-container-lowest border border-outline-variant/15 rounded-sm p-3 space-y-2">
            <div className="font-label text-[11px] uppercase tracking-wider text-on-surface-variant">Rule Summary</div>
            {details.ruleSummary.text ? (
              <p className="font-body text-sm text-on-surface">{details.ruleSummary.text}</p>
            ) : (
              <p className="font-mono text-xs text-outline">No free-text rule summary provided.</p>
            )}

            <div className="grid grid-cols-2 gap-2 font-mono text-[10px] text-on-surface-variant">
              <div>
                weekly fail limit:{' '}
                {details.ruleSummary.structured.noMoreThanFailuresPerWeek ?? 'off'}
              </div>
              <div>
                reset streak:{' '}
                {details.ruleSummary.structured.resetStreakOnFailure === false ? 'off' : 'on'}
              </div>
              <div>
                mandatory check-in:{' '}
                {details.ruleSummary.structured.mandatoryDailyCheckIn ? 'on' : 'off'}
              </div>
              <div>
                sync to personal:{' '}
                {details.ruleSummary.structured.syncToPersonal ? 'on' : 'off'}
              </div>
            </div>

            {details.ruleSummary.consequenceRules && (
              <div className="font-mono text-[10px] text-tertiary bg-tertiary/10 rounded-sm p-2 border border-tertiary/20">
                {details.ruleSummary.consequenceRules}
              </div>
            )}
          </div>

          <div className="bg-surface-container-lowest border border-outline-variant/15 rounded-sm p-3 space-y-2">
            <div className="font-label text-[11px] uppercase tracking-wider text-on-surface-variant">Participants</div>
            <div className="max-h-[200px] overflow-y-auto divide-y divide-outline-variant/10">
              {activeParticipants.map((participant) => {
                const participantConsequenceStates = details.consequenceStatusByParticipant[participant.id] || [];
                return (
                  <div key={participant.id} className="py-2 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-body text-sm text-on-surface">
                        {participant.username}
                        {participant.role === 'owner' ? ' (owner)' : ''}
                      </div>
                      <div className="font-mono text-[10px] text-on-surface-variant">
                        fails: {participant.totalFailures}
                        {participant.lastFailureAt
                          ? ` • last ${dayjs(participant.lastFailureAt).format('MMM D HH:mm')}`
                          : ' • no failures'}
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`font-mono text-[10px] ${
                          participant.status === 'failed' ? 'text-error' : 'text-primary'
                        }`}
                      >
                        {participant.status.toUpperCase()}
                      </div>
                      {participantConsequenceStates.length > 0 && (
                        <div className="font-mono text-[10px] text-error">
                          {participantConsequenceStates.length} consequence(s)
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Leaderboard rows={details.leaderboard} />
        <FailureFeed failures={details.recentFailures} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-4 space-y-3">
          <div className="font-headline text-sm font-semibold uppercase tracking-wide text-on-surface">
            <span className="text-primary">&gt;</span> Consequences
          </div>

          {details.consequences.length === 0 ? (
            <div className="font-mono text-xs text-outline">No consequence thresholds configured yet.</div>
          ) : (
            <div className="space-y-2">
              {details.consequences.map((consequence) => (
                <div
                  key={consequence.id}
                  className="p-2 rounded-sm bg-surface-container-lowest border border-outline-variant/15"
                >
                  <div className="font-body text-sm text-on-surface">
                    {consequence.symbol ? `${consequence.symbol} ` : ''}
                    {consequence.description}
                  </div>
                  <div className="font-mono text-[10px] text-on-surface-variant">
                    threshold: {consequence.failureThreshold} • type: {consequence.consequenceType}
                  </div>
                </div>
              ))}
            </div>
          )}

          {isOwner && (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
              <input
                type="number"
                min={1}
                value={newThreshold}
                onChange={(e) => setNewThreshold(e.target.value)}
                className="bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
                placeholder="Threshold"
              />
              <input
                value={newConsequenceDescription}
                onChange={(e) => setNewConsequenceDescription(e.target.value)}
                className="md:col-span-2 bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
                placeholder="Consequence"
              />
              <select
                value={newConsequenceType}
                onChange={(e) =>
                  setNewConsequenceType(e.target.value as 'text' | 'symbolic' | 'warning' | 'penalty')
                }
                className="bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
              >
                <option value="text">text</option>
                <option value="symbolic">symbolic</option>
                <option value="warning">warning</option>
                <option value="penalty">penalty</option>
              </select>
              <div className="flex gap-2">
                <input
                  value={newConsequenceSymbol}
                  onChange={(e) => setNewConsequenceSymbol(e.target.value)}
                  className="w-full bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
                  placeholder="Symbol"
                />
                <button
                  onClick={handleConsequence}
                  className="px-2.5 py-1.5 rounded-sm bg-primary/20 text-primary font-label text-[10px] uppercase"
                >
                  Add
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-4 space-y-3">
          <div className="font-headline text-sm font-semibold uppercase tracking-wide text-on-surface">
            <span className="text-primary">&gt;</span> Encouragement Feed
          </div>

          <div className="max-h-[180px] overflow-y-auto divide-y divide-outline-variant/10">
            {details.reactions.length === 0 ? (
              <div className="py-3 font-mono text-xs text-outline">No encouragement messages yet.</div>
            ) : (
              details.reactions.map((reaction) => (
                <div key={reaction.id} className="py-2">
                  <div className="font-body text-sm text-on-surface">
                    {reaction.emoji} {reaction.fromUsername}
                    {reaction.toUsername ? ` -> ${reaction.toUsername}` : ''}
                  </div>
                  {reaction.message && (
                    <div className="font-mono text-[10px] text-on-surface-variant mt-0.5">{reaction.message}</div>
                  )}
                </div>
              ))
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
            <select
              value={encourageTarget}
              onChange={(e) => setEncourageTarget(e.target.value)}
              className="bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
            >
              <option value="">All participants</option>
              {activeParticipants.map((participant) => (
                <option key={participant.id} value={participant.userId}>
                  {participant.username}
                </option>
              ))}
            </select>
            <input
              value={encourageEmoji}
              onChange={(e) => setEncourageEmoji(e.target.value)}
              className="bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
              placeholder="emoji"
            />
            <input
              value={encourageMessage}
              onChange={(e) => setEncourageMessage(e.target.value)}
              className="md:col-span-2 bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
              placeholder="message"
            />
            <button
              onClick={handleEncourage}
              className="px-3 py-1.5 rounded-sm bg-secondary/20 text-secondary font-label text-[10px] uppercase"
            >
              Send
            </button>
          </div>
        </div>
      </div>

      {isOwner && (
        <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-4 space-y-3">
          <div className="font-headline text-sm font-semibold uppercase tracking-wide text-on-surface">
            <span className="text-primary">&gt;</span> Invite Participants
          </div>

          {copyFeedback && (
            <div className="font-mono text-[11px] text-secondary bg-secondary/10 border border-secondary/20 rounded-sm px-2 py-1.5">
              {copyFeedback}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            <input
              value={inviteUsername}
              onChange={(e) => setInviteUsername(e.target.value)}
              className="bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
              placeholder="username (optional)"
            />
            <input
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              className="bg-surface-container-lowest border border-outline-variant/20 rounded-sm px-2 py-1.5 text-sm text-on-surface"
              placeholder="email (optional)"
            />
            <button
              onClick={handleInvite}
              className="px-3 py-1.5 rounded-sm bg-primary/20 text-primary font-label text-[10px] uppercase"
            >
              Create Invite
            </button>
          </div>

          <div className="max-h-[180px] overflow-y-auto divide-y divide-outline-variant/10">
            {details.invites.length === 0 ? (
              <div className="py-3 font-mono text-xs text-outline">No invites issued yet.</div>
            ) : (
              details.invites.map((invite) => (
                <div key={invite.id} className="py-2">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="font-body text-sm text-on-surface">
                        {invite.inviteeUsername || invite.inviteeEmail || 'link invite'}
                      </div>
                      <div className="font-mono text-[10px] text-on-surface-variant mt-0.5">
                        token: {invite.token.slice(0, 12)}... • status: {invite.status}
                      </div>
                      <div className="font-mono text-[10px] text-secondary mt-0.5 break-all">
                        {invite.inviteLinkPath}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        void copyInviteLink(invite.inviteLinkPath);
                      }}
                      className="px-2.5 py-1 rounded-sm bg-secondary/20 text-secondary font-label text-[10px] uppercase"
                    >
                      Copy Link
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
