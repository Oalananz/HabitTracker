'use client';

import dayjs from 'dayjs';
import type { JourneyCatalogResponse } from './types';

interface JourneyListProps {
  catalog: JourneyCatalogResponse;
  selectedJourneyId: string | null;
  onSelectJourney: (journeyId: string) => void;
  onJoinPublicJourney: (journeyId: string) => Promise<void>;
  onRespondInvite: (
    journeyId: string,
    token: string,
    decision: 'accept' | 'decline'
  ) => Promise<void>;
}

function visibilityChip(visibility: 'private' | 'public') {
  if (visibility === 'public') {
    return <span className="px-2 py-0.5 rounded-sm bg-secondary/20 text-secondary font-mono text-[10px]">PUBLIC</span>;
  }

  return <span className="px-2 py-0.5 rounded-sm bg-tertiary/20 text-tertiary font-mono text-[10px]">PRIVATE</span>;
}

export default function JourneyList({
  catalog,
  selectedJourneyId,
  onSelectJourney,
  onJoinPublicJourney,
  onRespondInvite,
}: JourneyListProps) {
  return (
    <div className="bg-surface-container-low rounded-md border border-outline-variant/15 p-5 space-y-6">
      <div>
        <h3 className="font-headline text-sm font-semibold text-on-surface uppercase tracking-wide">
          <span className="text-primary">&gt;</span> JOURNEY_LIST
        </h3>
        <p className="font-body text-xs text-on-surface-variant mt-1">
          Joined journeys, pending invites, and open public competitions.
        </p>
      </div>

      <div className="space-y-2">
        <div className="font-label text-[11px] uppercase tracking-widest text-on-surface-variant">
          Joined
        </div>

        {catalog.journeys.length === 0 ? (
          <div className="p-3 rounded-sm bg-surface-container-lowest border border-outline-variant/15 font-mono text-xs text-outline">
            No joined competitive journeys yet.
          </div>
        ) : (
          catalog.journeys.map((journey) => {
            const isActive = selectedJourneyId === journey.id;
            return (
              <button
                key={journey.id}
                onClick={() => onSelectJourney(journey.id)}
                className={`w-full text-left p-3 rounded-sm border transition-colors ${
                  isActive
                    ? 'border-primary/60 bg-primary/5'
                    : 'border-outline-variant/15 bg-surface-container-lowest hover:border-outline-variant/35'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="font-headline text-sm font-bold text-on-surface truncate">{journey.name}</div>
                  <div className="flex items-center gap-1.5">
                    {visibilityChip(journey.visibility)}
                    {journey.myStatus === 'failed' && (
                      <span className="px-2 py-0.5 rounded-sm bg-error-container text-on-error-container font-mono text-[10px]">
                        FAILED
                      </span>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-on-surface-variant">
                  <div>{journey.participantCount} peers</div>
                  <div>{journey.totalFailures} failures</div>
                  <div>{journey.myFailures} mine</div>
                </div>
              </button>
            );
          })
        )}
      </div>

      <div className="space-y-2">
        <div className="font-label text-[11px] uppercase tracking-widest text-on-surface-variant">
          Pending Invites
        </div>

        {catalog.pendingInvites.length === 0 ? (
          <div className="p-3 rounded-sm bg-surface-container-lowest border border-outline-variant/15 font-mono text-xs text-outline">
            No pending invites.
          </div>
        ) : (
          catalog.pendingInvites.map((invite) => (
            <div
              key={invite.id}
              className="p-3 rounded-sm border border-outline-variant/15 bg-surface-container-lowest"
            >
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="font-headline text-sm font-semibold text-on-surface">
                    {invite.journey?.name || 'Unknown Journey'}
                  </div>
                  <div className="font-mono text-[10px] text-on-surface-variant mt-0.5">
                    invited {dayjs(invite.createdAt).format('MMM D, HH:mm')}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => onRespondInvite(invite.journeyId, invite.token, 'decline')}
                    className="px-2.5 py-1 rounded-sm bg-surface-container-high text-on-surface-variant font-label text-[10px] uppercase tracking-wider"
                  >
                    Decline
                  </button>
                  <button
                    onClick={() => onRespondInvite(invite.journeyId, invite.token, 'accept')}
                    className="px-2.5 py-1 rounded-sm bg-scanline-gradient text-on-primary font-label text-[10px] uppercase tracking-wider font-bold"
                  >
                    Accept
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="space-y-2">
        <div className="font-label text-[11px] uppercase tracking-widest text-on-surface-variant">
          Public Journeys
        </div>

        {catalog.publicJourneys.length === 0 ? (
          <div className="p-3 rounded-sm bg-surface-container-lowest border border-outline-variant/15 font-mono text-xs text-outline">
            No public journeys available.
          </div>
        ) : (
          catalog.publicJourneys.map((journey) => (
            <div
              key={journey.id}
              className="p-3 rounded-sm border border-outline-variant/15 bg-surface-container-lowest"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-headline text-sm font-semibold text-on-surface truncate">{journey.name}</div>
                  <div className="font-mono text-[10px] text-on-surface-variant mt-0.5">
                    {journey.participantCount} participants • {journey.totalFailures} failures logged
                  </div>
                </div>
                <button
                  onClick={() => onJoinPublicJourney(journey.id)}
                  className="px-3 py-1.5 rounded-sm bg-secondary/20 text-secondary font-label text-[10px] uppercase tracking-wider font-bold"
                >
                  Join
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
